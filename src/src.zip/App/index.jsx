import { MultipleChocies } from "../components/Filtres";
import { SearchBox } from "../components/SearchBox";

const App = () => {
    return (
        <div className="flex h-screen p-1">
            <div
                id="filter"
                className="min-w-[200px] max-w-[300px] h-full border border-black px-2">
                    <MultipleChocies    
                        id="searchBoxFilter"
                        title="Arama Filtresi"/>
                </div>
            <div
                className="flex justify-center items-start w-full h-full border ml-1 border-black p-1"
                id="list">
                <div className="w-full flex flex-col">
                    <div
                        id="searchBox"
                        className="w-full min-h-[30px] border border-black mb-1">
                        <SearchBox/>
                    </div>
                    <div
                        id="table"
                        className="border border-black w-full mt-1">
                        Tablo İçeriği
                    </div>
                </div>
            </div>

        </div>
    )
}
export default App;