const useNavigator = (path) =>{
    
}
export default useNavigator;