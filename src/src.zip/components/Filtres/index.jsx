import { useEffect, useState } from "react";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import PropTypes from "prop-types";
const defaultItems = [
    { label: "Hepsi", id: "1", value: "all" },
    { label: "İsim Soyisim", id: "2", value: "nameSurname" },
    { label: "Kimlik Numarası", id: "3", value: "tcId" },
    { label: "Vergi Numarası", id: "4", value: "taxtId" },
    { label: "Telefon Numarası", id: "5", value: "phone" },
]
const urlParams = new URLSearchParams(typeof window !== "undefined" ? window.location.search : "");
const MultipleChocies = (props) => {
    const [view, setView] = useState(props.view);
    const handleView = async () => {
        await setView(prev => !prev)
        if (view)
            urlParams.delete(props.id)
        else
            urlParams.set(props.id, "")
        await window.history.pushState({}, '', `${window.location.pathname}?${urlParams.toString()}`)
    }
    useEffect(() => {
        const data = urlParams.get(props.id, "")
        if (data === "")
            setView(true)
    }, [props.id])
    return (
        <div className="px-2">
            <div className="flex justify-between items-center mb-1">
                <div
                    onClick={handleView}
                    className="text-sm text-gray-600 cursor-pointer p-1"><b>{props.title}</b></div>
                <div
                    className="cursor-pointer p-1 rounded-full hover:text-blue-600"
                    onClick={handleView}>{view ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}</div>
            </div>
            {view ? props.items.length ?
                <div
                    id="select-items"
                    className="border border-black w-full min-h-[25px] max-h-[200px] overflow-y-auto">
                    <ul>
                        {props.items.map((Item, i) => <CreateSelectItemsWithCheckbox label={Item.label} checked={Item.checked} value={Item.value} key={i} />)}
                    </ul>
                </div> : props.notFount
                : null}
        </div>
    )
}
MultipleChocies.defaultProps = {
    title: "Multiple Chocies",
    id: "MultipleChocies",
    notFount: <div className="h-[100px] flex items-center justify-center border border-black">Bulunamadı</div>,
    view: false,
    items: defaultItems
};
const CreateSelectItemsWithCheckbox = (props) => {
    const [checked, setChecked] = useState(props.checked);
    const handleChecked = () => {
        setChecked(prev => !prev);
        const urlParams = new URLSearchParams(window.location.search);
        const data = urlParams.get("filters");
        if (data) {
            let validFilters = data.split(","); 
            if (validFilters.includes(props.value)) {
                validFilters = validFilters.filter(fd => fd !== props.value);
            } else {
                validFilters.push(props.value);
            }
            if (validFilters.length > 0) {
                urlParams.set("filters", validFilters.join(","));
            } else {
                urlParams.delete("filters");
            }
        } else {
            urlParams.set("filters", props.value);
        }
        window.history.pushState({}, '', `${window.location.pathname}?${urlParams.toString()}`);

        console.log(urlParams.toString());

    };
    useEffect(() => {
        const data = urlParams.get("filters")
        if (data && data.split(",").includes(props.value)) setChecked(true)
    }, [props.value])
    if (props.label === "") return <li className="flex items-center animate-pulse w-24 h-3 bg-gray-400 rounded-full m-1" />
    else return (
        <li className="flex items-center">
            <input
                type="checkbox"
                id={`checkboxItem-${props.value}`}  // Her item için benzersiz id
                value={props.value}
                onChange={handleChecked}
                checked={checked}
            />
            <label
                className="ml-2"
                htmlFor={`checkboxItem-${props.value}`}  // Her item için benzersiz id
            >
                {props.label}
            </label>
        </li>
    );
};
CreateSelectItemsWithCheckbox.defaultProps = {
    checked: false,
    label: "",
    value: ""
}
CreateSelectItemsWithCheckbox.prototype = {
    checked: PropTypes.bool,
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired
}
export { MultipleChocies }