import { Search } from "@mui/icons-material";
import { Input, IconButton } from "@mui/material";
import { useEffect, useState } from "react";

const SearchBox = () => {
    const [value, setValue] = useState("");
    const [placeHolder, setPlaceHolder] = useState("Ad-soyad, telefon, kimlik numarası ya da vergi numarası ile arayın...");
    const [urlParams, setUrlParams] = useState(new URLSearchParams(window.location.search)); // Track URL parameters in state

    const handleChange = (e) => setValue(e.target.value);

    const handleSubmit = (e) => {
        e.preventDefault();
        urlParams.set("q", value);

        const filterType = urlParams.get("filters");
        if (!filterType || filterType === "all") {
            urlParams.set("filters", "all");
        }

        const url = window.location.pathname.concat("?");
        window.history.pushState({}, "", url.concat(urlParams.toString()));
        setUrlParams(new URLSearchParams(window.location.search)); // Update state after URL change
    };

    // Update placeholder and value based on URL parameters
    useEffect(() => {
        const filterDatas = urlParams.get("filters");
        if (filterDatas) {
            const textObject = {
                "nameSurname": "Ad-soyad",
                "phone": "telefon",
                "tcId": "kimlik numarası",
                "taxId": "vergi numarası",
            };

            const data = filterDatas.split(",");
            if (!data.includes("all")) {
                const validFilters = data.map((fid) => textObject[fid]).filter(Boolean);
                if (validFilters.length > 0) {
                    const lastFilter = validFilters.pop();
                    const data = validFilters.length > 0
                        ? `${validFilters.join(", ")} ya da ${lastFilter} ile arayın...`
                        : `${lastFilter} ile arayın...`;
                    setPlaceHolder(data);
                } else {
                    setPlaceHolder("Ad-soyad, telefon, kimlik numarası ya da vergi numarası ile arayın...");
                }
            } else {
                setPlaceHolder("Ad-soyad, telefon, kimlik numarası ya da vergi numarası ile arayın...");
            }
        }
    }, [urlParams]); // Depend on urlParams instead of window.location.search

    // Update the value when the query parameter "q" changes
    useEffect(() => {
        const query = urlParams.get("q");
        if (query) {
            setValue(query);
        }
    }, [urlParams]); // Depend on urlParams instead of window.location.search

    return (
        <form onSubmit={handleSubmit}>
            <Input
                fullWidth
                value={value}
                onChange={handleChange}
                placeholder={placeHolder}
            />
            <IconButton
                type="submit"
                sx={{
                    ml: -5,
                    '&:hover': { backgroundColor: 'transparent' },
                    '&:active': { backgroundColor: 'transparent' },
                    '&:focus': { backgroundColor: 'transparent' }
                }}
            >
                <Search />
            </IconButton>
        </form>
    );
};

export { SearchBox };
