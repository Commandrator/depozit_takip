import React, { createContext, useContext, useState } from 'react';

// Example of a settings context
const SettingsContext = createContext<any>(null);

const SettingsProvider: React.FC = ({ children }) => {
    const [theme, setTheme] = useState("light");

    const toggleTheme = () => {
        setTheme(prevTheme => (prevTheme === "light" ? "dark" : "light"));
    };

    return (
        <SettingsContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </SettingsContext.Provider>
    );
};

const App: React.FC = () => {
    return (
        <SettingsProvider>
            <AppProvider /> {/* Your AppProvider here */}
        </SettingsProvider>
    );
};

const useSettings = () => {
    return useContext(SettingsContext);
};
