import { createContext } from "react"
const AppContext  = createContext(undefined);
export {AppContext}
export default AppContext